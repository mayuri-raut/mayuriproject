 <!-- footer starts here -->

    <footer>
    <section class="footer">
      <div class="col-md-3 col-sm-6 col-xs-12 set-padding-footer">
        <div class="footer-1">
            <h2>About Us</h2>

            <p> Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
              tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
              quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
              consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
              cillum dolore eu fugiat nulla pariatur.</p>
        </div>     
      </div>

       <div class="col-md-3 col-sm-6 col-xs-12 set-padding-footer">
           <div class="footer-1">
             <h2>Stay Tuned</h2>
             <h3>Stay Connect with us and stay in the loop</h3>
             <ul class="social-icons">
               <li><i class="fa fa-facebook"></i> </li>
               <li><i class="fa fa-twitter"></i> </li>
             </ul>
           </div> 
      </div>

       <div class="col-md-3 col-sm-6 col-xs-12  set-padding-footer clear-link">
         <div class="footer-1">
          <h2>Important Links</h2>
           <div class="contact-footer2">
                  <ul>
                    <li><a href="#">Site Map</a></li>
                    <li><a href="#">Privacy Policy</a></li>
                    <li><a href="#">Contact Us</a></li>
                  </ul>
              </div>
         </div> 
      </div>

       <div class="col-md-3 col-sm-6 col-xs-12 set-padding-footer">
          <div class="footer-1">
           <h2>Contact Us</h2>
          <h3>Questions? we've got answers.Try us. </h3>
             <div class="contact-footer">
             <input type="text" placeholder="Full Name">
             <input type="text" placeholder="Email ID">
             <input type="text" placeholder="Mobile Number">
             <input type="submit" value="Submit" class="submit-form">
             <!-- <textarea placeholder="Message"></textarea> -->
          </div> 
      </div>
      </div>
</section>

<section class="subfooter">
 <h5>© 2017 JOHN DOE ALL RIGHTS RESERVED</h5> 
</section>
    </footer>

    <script type="text/javascript" src="js/jquery.min.js"></script>
    <!-- script js for slider page two -->
<script type="text/javascript" src="js/jquery.min.js"></script>
 --><script type="text/javascript">
  
  $(document).on('ready', function() {
  var slide = $('.slider-single');
  var slideTotal = slide.length - 1;
  var slideCurrent = -1;

  function slideInitial() {
    slide.addClass('proactivede');
    setTimeout(function() {
      slideRight();
    }, 500);
  }

  function slideRight() {
    if (slideCurrent < slideTotal) {
      slideCurrent++;
    } else {
      slideCurrent = 0;
    }

    if (slideCurrent > 0) {
      var preactiveSlide = slide.eq(slideCurrent - 1);
    } else {
      var preactiveSlide = slide.eq(slideTotal);
    }
    var activeSlide = slide.eq(slideCurrent);
    if (slideCurrent < slideTotal) {
      var proactiveSlide = slide.eq(slideCurrent + 1);
    } else {
      var proactiveSlide = slide.eq(0);

    }

    slide.each(function() {
      var thisSlide = $(this);
      if (thisSlide.hasClass('preactivede')) {
        thisSlide.removeClass('preactivede preactive active proactive').addClass('proactivede');
      }
      if (thisSlide.hasClass('preactive')) {
        thisSlide.removeClass('preactive active proactive proactivede').addClass('preactivede');
      }
    });
    preactiveSlide.removeClass('preactivede active proactive proactivede').addClass('preactive');
    activeSlide.removeClass('preactivede preactive proactive proactivede').addClass('active');
    proactiveSlide.removeClass('preactivede preactive active proactivede').addClass('proactive');
  }

  function slideLeft() {
    if (slideCurrent > 0) {
      slideCurrent--;
    } else {
      slideCurrent = slideTotal;
    } 
    if (slideCurrent < slideTotal) {
      var proactiveSlide = slide.eq(slideCurrent + 1);
    } else {
      var proactiveSlide = slide.eq(0);
    }
    var activeSlide = slide.eq(slideCurrent);
    if (slideCurrent > 0) {
      var preactiveSlide = slide.eq(slideCurrent - 1);
    } else {
      var preactiveSlide = slide.eq(slideTotal);
    }
    slide.each(function() {
      var thisSlide = $(this);
      if (thisSlide.hasClass('proactivede')) {
        thisSlide.removeClass('preactive active proactive proactivede').addClass('preactivede');
      }
      if (thisSlide.hasClass('proactive')) {
        thisSlide.removeClass('preactivede preactive active proactive').addClass('proactivede');
      }
    });
    preactiveSlide.removeClass('preactivede active proactive proactivede').addClass('preactive');
    activeSlide.removeClass('preactivede preactive proactive proactivede').addClass('active');
    proactiveSlide.removeClass('preactivede preactive active proactivede').addClass('proactive');
  }
  var left = $('.slider-left');
  var right = $('.slider-right');
  left.on('click', function() {
    slideLeft();
  });
  right.on('click', function() {
    slideRight();
  });
  slideInitial();
});
</script>
      <script type="text/javascript" src="js/slick.min.js"></script>
   <script type="text/javascript" src="js/bootstrap.min.js"></script>
   <script type="text/javascript" src="js/bootstrap-material-design.js"></script>
   <script type="text/javascript" src="js/all.js"></script>
<!-- map code -->
    <script>
                function initMap() {
                    var uluru = {
                        lat: -25.363,
                        lng: 131.044
                    };
                    var map = new google.maps.Map(document.getElementById('map'), {
                        zoom: 4,
                        center: uluru
                    });
                    var marker = new google.maps.Marker({
                        position: uluru,
                        map: map
                    });
                }
            </script>
            <script async defer src="https://maps.googleapis.com/maps/api/js?key=AIzaSyD07CwiBwyLQNTxmEq3xaxMtQfAhCfaqDs&callback=initMap">
            </script>
 

<!-- popup -->



<!-- <a href="#" data-toggle="modal" data-target="#login-modal">Login</a> -->

                                    <div class="modal fade" id="login-modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true" style="    display: none;">
                                        <div class="modal-dialog margin-setting">
                                            <div class="loginmodal-container">
                                            <div class="login-form-section">
                                                 <h1>Login </h1>
                                                </div>
                                                <div class="form-dialog">
                                                <form>
                                                    <div class="form-group">
                                                        <input type="text" required="required" />
                                                        <label class="control-label" for="input">Username</label><i class="bar"></i>
                                                    </div>

                                                    <div class="form-group">
                                                        <input type="password" required="required" />
                                                        <label class="control-label" for="input">Password</label><i class="bar"></i>
                                                    </div>

                                                    <input type="submit" name="login" class="login loginmodal-submit" value="Login">
                                                </form>

                                                <!-- <div class="login-help">
                                                     <a href="#">Forgot Password</a>
                                                </div> -->
                                            </div>
                                        </div>
                                    </div>





</body>

</html>